package com.vaibhav.ws.bank.ui.model.request;

public class RequestData {
	
	private String UVR;
	private String transactionid;
	public String getUVR() {
		return UVR;
	}
	public void setUVR(String uVR) {
		UVR = uVR;
	}
	public String getTransactionid() {
		return transactionid;
	}
	public void setTransactionid(String transactionid) {
		this.transactionid = transactionid;
	}

}
